﻿namespace MaJiCSoft.ChatOverlay.OAuth.Options
{
    public class OAuthAccessOptions
    {
        public string AccessToken { get; set; }
    }
}
